// This file handles the logic for entering and displaying weight data.

let weightData = [];

// Function to add weight entry
function addWeightEntry(employeeId, weight) {
    const entry = {
        employeeId: employeeId,
        weight: weight,
        date: new Date().toISOString().split('T')[0] // Store date in YYYY-MM-DD format
    };
    weightData.push(entry);
    localStorage.setItem('weightData', JSON.stringify(weightData));
}

// Function to get weight history for a specific employee
function getWeightHistory(employeeId) {
    const storedData = localStorage.getItem('weightData');
    if (storedData) {
        weightData = JSON.parse(storedData);
    }
    return weightData.filter(entry => entry.employeeId === employeeId);
}

// Function to display weight history
function displayWeightHistory(employeeId) {
    const history = getWeightHistory(employeeId);
    const historyContainer = document.getElementById('weight-history');
    historyContainer.innerHTML = '';

    history.forEach(entry => {
        const entryElement = document.createElement('div');
        entryElement.textContent = `Date: ${entry.date}, Weight: ${entry.weight} kg`;
        historyContainer.appendChild(entryElement);
    });
}

// Function to initialize weight tracker
function initWeightTracker() {
    const storedData = localStorage.getItem('weightData');
    if (storedData) {
        weightData = JSON.parse(storedData);
    }
}

// Call the initialization function on page load
document.addEventListener('DOMContentLoaded', initWeightTracker);
// This file contains the main JavaScript functionalities for the weight loss competition website.

document.addEventListener('DOMContentLoaded', () => {
    // Initialize the application
    console.log('Weight Loss Competition App Initialized');

    // Add event listeners for navigation links
    const navLinks = document.querySelectorAll('a.nav-link');
    navLinks.forEach(link => {
        link.addEventListener('click', (event) => {
            event.preventDefault();
            const targetPage = link.getAttribute('href');
            loadPage(targetPage);
        });
    });
});

// Function to load different pages dynamically
function loadPage(page) {
    fetch(page)
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.text();
        })
        .then(html => {
            document.getElementById('content').innerHTML = html;
        })
        .catch(error => {
            console.error('There was a problem with the fetch operation:', error);
        });
}
// This file manages authentication, including login and registration processes.

document.addEventListener('DOMContentLoaded', function() {
    const registrationForm = document.getElementById('registration-form');
    const loginForm = document.getElementById('login-form');

    if (registrationForm) {
        registrationForm.addEventListener('submit', function(event) {
            event.preventDefault();
            const formData = new FormData(registrationForm);
            const data = {
                username: formData.get('username'),
                password: formData.get('password'),
                email: formData.get('email')
            };
            registerUser(data);
        });
    }

    if (loginForm) {
        loginForm.addEventListener('submit', function(event) {
            event.preventDefault();
            const formData = new FormData(loginForm);
            const data = {
                username: formData.get('username'),
                password: formData.get('password')
            };
            loginUser(data);
        });
    }
});

function registerUser(data) {
    // Simulate an API call for registration
    console.log('Registering user:', data);
    // Here you would typically send a request to your server
}

function loginUser(data) {
    // Simulate an API call for login
    console.log('Logging in user:', data);
    // Here you would typically send a request to your server
}
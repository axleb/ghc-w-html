// This file manages the logic for calculating and displaying the leaderboard.

const leaderboardData = [];

// Function to fetch leaderboard data from local storage or server
function fetchLeaderboardData() {
    const data = JSON.parse(localStorage.getItem('leaderboard')) || [];
    leaderboardData.push(...data);
    displayLeaderboard();
}

// Function to display the leaderboard
function displayLeaderboard() {
    const leaderboardContainer = document.getElementById('leaderboard');
    leaderboardContainer.innerHTML = '';

    // Sort the leaderboard data by weight lost
    leaderboardData.sort((a, b) => (a.initialWeight - a.finalWeight) - (b.initialWeight - b.finalWeight));

    // Get top three employees
    const topThree = leaderboardData.slice(0, 3);

    topThree.forEach((employee, index) => {
        const entry = document.createElement('div');
        entry.classList.add('leaderboard-entry');
        entry.innerHTML = `
            <h3>${index + 1}. ${employee.name}</h3>
            <p>Weight Lost: ${employee.initialWeight - employee.finalWeight} lbs</p>
        `;
        leaderboardContainer.appendChild(entry);
    });
}

// Call the fetch function on page load
document.addEventListener('DOMContentLoaded', fetchLeaderboardData);
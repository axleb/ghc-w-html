# Weight Loss Competition

This project is a web application designed to facilitate a weight loss competition among employees. It includes features for registration, login, weight entry, weight history tracking, a leaderboard, and an admin panel for managing the competition.

## Project Structure

```
weight-loss-competition
├── index.html               # Home page of the website
├── pages
│   ├── registration.html    # Registration page for new employees
│   ├── login.html           # Login page for employees
│   ├── weight-entry.html     # Page for entering weight data
│   ├── weight-history.html   # Page displaying weight history of logged-in employees
│   ├── leaderboard.html      # Page showing the top three employees
│   └── admin.html           # Admin page for calculations and data management
├── css
│   ├── styles.css           # Main stylesheet for the website
│   ├── home.css             # Styles specific to the home page
│   ├── registration.css      # Styles specific to the registration page
│   ├── login.css            # Styles specific to the login page
│   ├── weight-entry.css      # Styles specific to the weight entry page
│   ├── weight-history.css    # Styles specific to the weight history page
│   ├── leaderboard.css       # Styles specific to the leaderboard page
│   └── admin.css            # Styles specific to the admin page
├── js
│   ├── main.js              # Main JavaScript file for common functionalities
│   ├── auth.js              # JavaScript for authentication processes
│   ├── weight-tracker.js     # Logic for entering and displaying weight data
│   ├── leaderboard.js        # Logic for calculating and displaying the leaderboard
│   └── admin.js             # Functions for admin data management
└── README.md                # Documentation for the project
```

## Features

- **User Registration**: New employees can register for the competition by providing their details.
- **User Login**: Employees can log in to access their weight entry and history.
- **Weight Entry**: Logged-in employees can enter their weights through a simple form.
- **Weight History**: Employees can view their weight history to track their progress.
- **Leaderboard**: The top three employees who have lost the most weight are displayed on the leaderboard.
- **Admin Panel**: Admin users can perform calculations and manage competition data.

## Setup Instructions

1. Clone the repository to your local machine.
2. Open the `index.html` file in your web browser to view the home page.
3. Navigate through the pages to explore the features of the application.

## Technologies Used

- HTML
- CSS
- JavaScript

This project aims to promote healthy competition among employees and encourage them to achieve their weight loss goals.
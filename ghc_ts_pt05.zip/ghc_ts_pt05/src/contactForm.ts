window.addEventListener('DOMContentLoaded', () => {
    const form = document.querySelector('form') as HTMLFormElement;
    const usernameInput = document.getElementById('username') as HTMLInputElement;
    const emailInput = document.getElementById('email') as HTMLInputElement;

    // Remove native validation
    usernameInput.removeAttribute('required');
    emailInput.removeAttribute('required');
    form.noValidate = true;

    // Helper to show error message
    function showError(input: HTMLInputElement, message: string) {
        let error = input.nextElementSibling as HTMLElement;
        if (!error || !error.classList.contains('error-message')) {
            error = document.createElement('div');
            error.className = 'error-message';
            error.style.color = '#e63946';
            error.style.marginBottom = '1em';
            input.parentNode?.insertBefore(error, input.nextSibling);
        }
        error.textContent = message;
    }

    // Helper to remove error message
    function removeError(input: HTMLInputElement) {
        let error = input.nextElementSibling as HTMLElement;
        if (error && error.classList.contains('error-message')) {
            error.remove();
        }
    }

    usernameInput.addEventListener('blur', () => {
        const username = usernameInput.value.trim();
        const hasNumber = /\d/.test(username);
        if (username.length < 3) {
            usernameInput.style.border = '2px solid #e63946';
            showError(usernameInput, 'Username must be at least 3 characters.');
        } else if (hasNumber) {
            usernameInput.style.border = '2px solid #e63946';
            showError(usernameInput, 'Username must not contain numbers.');
        } else {
            usernameInput.style.border = '2px solid #43d9ad';
            removeError(usernameInput);
        }
    });

    usernameInput.addEventListener('input', () => {
        usernameInput.style.border = '';
        removeError(usernameInput);
    });

    emailInput.addEventListener('blur', () => {
        const email = emailInput.value.trim();
        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailPattern.test(email)) {
            emailInput.style.border = '2px solid #e63946';
            showError(emailInput, 'Please enter a valid email address.');
        } else {
            emailInput.style.border = '2px solid #43d9ad';
            removeError(emailInput);
        }
    });

    emailInput.addEventListener('input', () => {
        emailInput.style.border = '';
        removeError(emailInput);
    });

    form.addEventListener('submit', (e) => {
        e.preventDefault(); // Prevent submission for demonstration
        // You can add further validation or submission logic here
    });
});
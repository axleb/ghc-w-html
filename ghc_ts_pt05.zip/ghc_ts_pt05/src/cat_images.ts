window.addEventListener('DOMContentLoaded', () => {
    const container = document.getElementById('cat-container');
    if (!container) return;

    // Fetch 8 random cat images with breed info
    fetch('https://api.thecatapi.com/v1/images/search?limit=8&has_breeds=1')
        .then(res => res.json())
        .then(data => {
            if (Array.isArray(data) && data.length > 0) {
                const table = document.createElement('table');
                table.style.margin = '0 auto';
                table.style.borderCollapse = 'collapse';
                table.style.background = '#22223b';
                table.style.color = '#fff';

                data.forEach((cat: { url: string, breeds?: Array<{ name: string }> }) => {
                    const row = document.createElement('tr');

                    // Image cell
                    const imgCell = document.createElement('td');
                    imgCell.style.border = '3px solid #43d9ad';
                    imgCell.style.padding = '10px';
                    imgCell.style.background = '#3a9ad9';
                    const img = document.createElement('img');
                    img.src = cat.url;
                    img.alt = 'Random Cat';
                    img.style.maxWidth = '180px';
                    img.style.borderRadius = '8px';
                    imgCell.appendChild(img);

                    // Breed cell
                    const breedCell = document.createElement('td');
                    breedCell.style.border = '3px solid #e63946';
                    breedCell.style.padding = '10px';
                    breedCell.style.background = '#43d9ad';
                    breedCell.style.fontWeight = 'bold';
                    breedCell.textContent = (cat.breeds && cat.breeds.length > 0)
                        ? cat.breeds[0].name
                        : 'Unknown Breed';

                    row.appendChild(imgCell);
                    row.appendChild(breedCell);
                    table.appendChild(row);
                });

                container.appendChild(table);
            } else {
                container.textContent = 'No cat images found.';
            }
        })
        .catch(() => {
            container.textContent = 'Failed to load cat images.';
        });
});
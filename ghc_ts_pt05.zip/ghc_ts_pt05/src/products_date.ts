window.addEventListener('DOMContentLoaded', () => {
    const dateDiv = document.getElementById('current-date');
    if (dateDiv) {
        const today = new Date();
        // Format as mm/dd/yyyy
        const mm = String(today.getMonth() + 1).padStart(2, '0');
        const dd = String(today.getDate()).padStart(2, '0');
        const yyyy = today.getFullYear();
        const formatted = `${mm}/${dd}/${yyyy}`;

        // Calculate days in business
        const startDate = new Date(2020, 0, 16); // January is 0
        const diffTime = today.getTime() - startDate.getTime();
        const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));

        // Calculate days to Christmas
        const christmas = new Date(today.getFullYear(), 11, 25); // December is 11
        const msToChristmas = christmas.getTime() - today.getTime();
        const daysToChristmas = Math.ceil(msToChristmas / (1000 * 60 * 60 * 24));

        dateDiv.innerHTML = `
            Today's date: ${formatted}<br>
            Days in business: ${diffDays}<br>
            <span style="font-size:2em; color:#FFD700;">
                Days to Christmas: ${daysToChristmas}
            </span>
        `;
    }
});
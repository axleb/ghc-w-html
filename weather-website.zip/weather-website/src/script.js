// This file contains JavaScript code that fetches weather data from an API and updates the HTML elements with the retrieved information.

// Public API version using Open-Meteo (no API key needed)

const cityInput = document.getElementById('cityInput');
const getWeatherBtn = document.getElementById('getWeatherBtn');

const temperatureEl = document.getElementById('temperature');
const descriptionEl = document.getElementById('description');
const humidityEl = document.getElementById('humidity');

getWeatherBtn.addEventListener('click', handleSearch);
cityInput.addEventListener('keydown', e => { if (e.key === 'Enter') handleSearch(); });

function handleSearch() {
    const city = cityInput.value.trim();
    if (!city) return;
    fetchWeatherData(city);
}

async function fetchWeatherData(city) {
    temperatureEl.textContent = 'Loading...';
    descriptionEl.textContent = '';
    humidityEl.textContent = '';

    try {
        // 1. Geocode city -> lat/lon
        const geoRes = await fetch(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(city)}&count=1&language=en&format=json`);
        if (!geoRes.ok) throw new Error('Geocoding failed');
        const geoData = await geoRes.json();
        if (!geoData.results || geoData.results.length === 0) {
            throw new Error('City not found');
        }
        const loc = geoData.results[0];
        const { latitude, longitude, name, country } = loc;

        // 2. Get current weather
        const wxRes = await fetch(
            `https://api.open-meteo.com/v1/forecast?latitude=${latitude}&longitude=${longitude}` +
            `&current=temperature_2m,relative_humidity_2m,weather_code&timezone=auto`
        );
        if (!wxRes.ok) throw new Error('Weather fetch failed');
        const wxData = await wxRes.json();

        if (!wxData.current) throw new Error('No data');

        displayWeather({
            name: `${name}${country ? ', ' + country : ''}`,
            temp: wxData.current.temperature_2m,
            humidity: wxData.current.relative_humidity_2m,
            code: wxData.current.weather_code
        });
    } catch (err) {
        temperatureEl.textContent = err.message;
        descriptionEl.textContent = '—';
        humidityEl.textContent = '—';
    }
}

function displayWeather({ name, temp, humidity, code }) {
    temperatureEl.textContent = `Temperature in ${name}: ${temp} °C`;
    descriptionEl.textContent = `Description: ${weatherCodeToText(code)}`;
    humidityEl.textContent = `Humidity: ${humidity}%`;
}

function weatherCodeToText(code) {
    const map = {
        0: 'Clear sky',
        1: 'Mainly clear',
        2: 'Partly cloudy',
        3: 'Overcast',
        45: 'Fog',
        48: 'Depositing rime fog',
        51: 'Light drizzle',
        53: 'Moderate drizzle',
        55: 'Dense drizzle',
        56: 'Freezing drizzle (light)',
        57: 'Freezing drizzle (dense)',
        61: 'Slight rain',
        63: 'Moderate rain',
        65: 'Heavy rain',
        66: 'Freezing rain (light)',
        67: 'Freezing rain (heavy)',
        71: 'Slight snow',
        73: 'Moderate snow',
        75: 'Heavy snow',
        77: 'Snow grains',
        80: 'Rain showers (slight)',
        81: 'Rain showers (moderate)',
        82: 'Rain showers (violent)',
        85: 'Snow showers (slight)',
        86: 'Snow showers (heavy)',
        95: 'Thunderstorm (slight/moderate)',
        96: 'Thunderstorm with slight hail',
        99: 'Thunderstorm with heavy hail'
    };
    return map[code] || 'Unknown';
}
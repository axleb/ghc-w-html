# Weather Website

This project is a simple weather information display website that fetches and shows weather data based on user input.

## Project Structure

```
weather-website
├── src
│   ├── index.html      # Main HTML document for the website
│   ├── script.js       # JavaScript code for fetching and displaying weather data
│   └── styles.css      # CSS styles for the website
└── README.md           # Documentation for the project
```

## Getting Started

To set up and run the weather website, follow these steps:

1. **Clone the repository**:
   ```
   git clone <repository-url>
   cd weather-website
   ```

2. **Open the project**:
   Open the `index.html` file in your web browser.

3. **API Key**:
   You may need an API key to fetch weather data. Sign up for a weather API service (like OpenWeatherMap) and replace the placeholder in `script.js` with your API key.

## Dependencies

This project does not have any external dependencies, but it relies on a weather API for fetching data.

## Usage

- Enter a city name in the input field and click the "Get Weather" button to fetch the current weather information for that city.
- The weather data will be displayed on the webpage, including temperature, humidity, and weather conditions.

## License

This project is open-source and available under the MIT License.